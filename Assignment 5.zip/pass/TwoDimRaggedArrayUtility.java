/*
 * Class: CMSC203 
 * Instructor: Professor Grigoriy Grinberg 
 * Description: Make a program that calculates holiday bonuses for stores in a retail district based on store sales in several categories.
 * Due: 07/24/2022
 * Platform/compiler: Eclipse
 * I pledge that I have completed the programming assignment independently.
   I have not copied the code from a student or any source.
   I have not given my code to any student.
   Print your Name here: _Mohammed Ali_
*/

package application;

import java.io.*;
import java.util.Scanner;

public final class TwoDimRaggedArrayUtility 
	{
//getters
		public static double getAverage(double[][] dataPass) 
			{
				double totalDiv;
				totalDiv = getTotal(dataPass);
				int counter;
				counter = 0;
				double returner;
				
				int indexRow1;
				for(indexRow1 = 0; indexRow1 < dataPass.length; indexRow1++) 
					{
						int indexCol1;
						for(indexCol1 = 0; indexCol1 < dataPass[indexRow1].length; indexCol1++) 
							{
								counter = counter + 1;
							}
					}
				
				if(counter != 0) 
					{
						returner = totalDiv / counter;
						return returner;
					}
				else 
					{	
						returner = 0.0;
						return returner;
					}
			}
	
		public static double getColumnTotal(double[][] dataPass, int colPass) 
			{
				double totalAd;
				totalAd = 0;
				
				int indexRow2;
				for(indexRow2 = 0; indexRow2 < dataPass.length; indexRow2++) 
					{
						if((colPass + 1) <= (dataPass[indexRow2].length)) 
							{
								totalAd = totalAd + dataPass[indexRow2][colPass];
							}
					}
				
				return totalAd;
			}
		
		public static double getHighestInArray(double[][] dataPass) 
			{
				double highestVal;
				highestVal = Double.NEGATIVE_INFINITY;
				
				int indexRow3;
				for(indexRow3 = 0; indexRow3 < dataPass.length; indexRow3++) 
					{
						int indexCol3;
						for(indexCol3 = 0; indexCol3 < dataPass[indexRow3].length; indexCol3++)
							{
								if(highestVal < dataPass[indexRow3][indexCol3]) 
									{
										highestVal = dataPass[indexRow3][indexCol3];
									}
							}
					}
				
				return highestVal;
			}
		
		public static double getHighestInColumn(double[][] dataPass, int colPass) 
			{
				double highestVal;
				highestVal = Double.NEGATIVE_INFINITY;
				
				int index1;
				for(index1 = 0; index1 < dataPass.length; index1++) 
					{
						if(((colPass + 1) <= (dataPass[index1].length)) && (highestVal < dataPass[index1][colPass])) 
							{
								highestVal = dataPass[index1][colPass];
							}
					}
				
				return highestVal;
		}
		
		public static int getHighestInColumnIndex(double[][] dataPass, int colPass) 
			{
				double highestVal;
				highestVal = Double.NEGATIVE_INFINITY;
				int highestIndex;
				highestIndex = 0;
				
				int index2;
				for(index2 = 0; index2 < dataPass.length; index2++) 
					{
						if(((colPass + 1) <= dataPass[index2].length) && (highestVal < dataPass[index2][colPass])) 
							{
								highestVal = dataPass[index2][colPass];
								highestIndex = index2;
							}
					}
				
				return highestIndex;
			}
		
		public static double getHighestInRow(double[][] dataPass, int rowPass) 
			{
				double highestVal;
				highestVal = Double.NEGATIVE_INFINITY;
				
				int index3;
				for(index3 = 0; index3 < dataPass[rowPass].length; index3++) 
					{
						if(highestVal < dataPass[rowPass][index3]) 
							{
								highestVal = dataPass[rowPass][index3];
							}
					}
				
				return highestVal;
			}
		
		public static int getHighestInRowIndex(double[][] dataPass, int rowPass) 
			{
				double highestVal;
				highestVal = Double.NEGATIVE_INFINITY;
				int highestIndex;
				highestIndex = 0;
				
				int index4;
				for(index4 = 0; index4 < dataPass[rowPass].length; index4++) 
					{
						if(highestVal < dataPass[rowPass][index4]) 
							{
								highestVal = dataPass[rowPass][index4];
								highestIndex = index4;
							}
					}
				
				return highestIndex;
		}
		
		public static double getLowestInArray(double[][] dataPass) 
			{
				double lowestVal;
				lowestVal = Double.MAX_VALUE;
				
				int indexRow4;
				for(indexRow4 = 0; indexRow4 < dataPass.length; indexRow4++) 
					{
						int indexCol4;
						for(indexCol4 = 0; indexCol4 < dataPass[indexRow4].length; indexCol4++) 
							{
								if(lowestVal > dataPass[indexRow4][indexCol4]) 
									{
										lowestVal = dataPass[indexRow4][indexCol4];
									}
							}
					}
				
				return lowestVal;
			}
		
		public static double getLowestInColumn(double[][] dataPass, int colPass) 
			{
				double lowestVal;
				lowestVal = Double.MAX_VALUE;
			
				int index5;
				for(index5 = 0; index5 < dataPass.length; index5++) 
					{
						if(((colPass + 1) <= dataPass[index5].length) && (lowestVal > dataPass[index5][colPass])) 
							{
								lowestVal = dataPass[index5][colPass];
							}
					}
				
				return lowestVal;
			}
		
		public static int getLowestInColumnIndex(double[][] dataPass, int colPass) 
			{
				double lowestVal;
				lowestVal = Double.MAX_VALUE;
				int lowestIndex;
				lowestIndex = 0;
				
				int index6;
				for(index6 = 0; index6 < dataPass.length; index6++) 
					{
						if(((colPass + 1) <= dataPass[index6].length) && (lowestVal > dataPass[index6][colPass])) 
							{
								lowestVal = dataPass[index6][colPass];
								lowestIndex = index6;
							}
					}
				
				return lowestIndex;
			}
		
		public static double getLowestInRow(double[][] dataPass, int rowPass) 
			{
				double lowestVal;
				lowestVal = Double.MAX_VALUE;
				
				int index7;
				for(index7 = 0; index7 < dataPass[rowPass].length; index7++) 
					{
						if(lowestVal > dataPass[rowPass][index7]) 
							{
								lowestVal = dataPass[rowPass][index7];
							}
					}
				
				return lowestVal;
			}
		
		public static int getLowestInRowIndex(double[][] dataPass, int rowPass) 
			{
				double lowestVal;
				lowestVal = Double.MAX_VALUE;
				int lowestIndex;
				lowestIndex = 0;
				
				int index8;
				for(index8 = 0; index8 < dataPass[rowPass].length; index8++) 
					{
						if(lowestVal > dataPass[rowPass][index8]) 
							{
								lowestVal = dataPass[rowPass][index8];
								lowestIndex = index8;
							}
					}
				
			return lowestIndex;
		}
		
		public static double getRowTotal(double[][] dataPass, int rowPass) 
			{
				double rowTotal;
				rowTotal = 0;
				
				int indexCol9;
				for(indexCol9 = 0; indexCol9 < dataPass[rowPass].length; indexCol9++) 
					{
						rowTotal = rowTotal + dataPass[rowPass][indexCol9];
					}
				
				return rowTotal;
			}
		
		public static double getTotal(double[][] dataPass) 
			{
				double fullTotal;
				fullTotal = 0;
				
				int indexRow10;
				for(indexRow10 = 0; indexRow10 < dataPass.length; indexRow10++) 
					{
						int indexCol10;
						for(indexCol10 = 0; indexCol10 < dataPass[indexRow10].length; indexCol10++) 
							{
								fullTotal = fullTotal + dataPass[indexRow10][indexCol10];
							}
					}
				
				return fullTotal;
		}
		
//file reader
		public static double[][] readFile(File file) throws FileNotFoundException 
			{
				if((file.length() == 0) || (file.exists() == false)) 
					{
						return null;
					}
	
				String[][] simpleStrArray;
				simpleStrArray = new String[10][10];
				String stringDealer;
				Scanner inputFileData = new Scanner(file);
	
				int lin;
				lin = 0;
				while(inputFileData.hasNext()) 
					{
						stringDealer = inputFileData.nextLine();
						simpleStrArray[lin] = stringDealer.split(" ");
						lin++;
					}
	
				int rowCounter;
				rowCounter = 0;
				int index11;
				for(index11 = 0; index11 < 10; index11++) 
					{
						if (simpleStrArray[index11][0] != null) 
							{
								rowCounter = rowCounter + 1;
							}
					}
	
				double[][] simpleDoubArray;
				simpleDoubArray= new double[rowCounter][];
	
				int colCounter;
				int index12;
				for(index12 = 0; index12 < rowCounter; index12++) 
					{
						colCounter = 0;
						int index13;
						for(index13 = 0; index13 < simpleStrArray[index12].length; index13++) 
							{
								colCounter = colCounter + 1;
							}
						
						simpleDoubArray[index12] = new double[colCounter];
						
						int index14;
						for(index14 = 0; index14 < colCounter; index14++) 
							{
								simpleDoubArray[index12][index14] = Double.valueOf(simpleStrArray[index12][index14]);
							}
					}
				
				inputFileData.close();
				
				return simpleDoubArray;
			}

//file writer
		public static void writeToFile(double[][] dataPass, File outputFile) throws FileNotFoundException 
			{
				PrintWriter opDataFile = new PrintWriter(outputFile);
				
				int index15;
				for(index15 = 0; index15 < dataPass.length; index15++) 
					{
						int index16;
						for(index16 = 0; index16 < dataPass[index15].length; index16++) 
							{
								opDataFile.print(dataPass[index15][index16] + " ");
							}
						
						opDataFile.print("\n");
					}
				
				opDataFile.close();
			}
	}