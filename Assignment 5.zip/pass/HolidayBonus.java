/*
 * Class: CMSC203 
 * Instructor: Professor Grigoriy Grinberg 
 * Description: Make a program that calculates holiday bonuses for stores in a retail district based on store sales in several categories.
 * Due: 07/24/2022
 * Platform/compiler: Eclipse
 * I pledge that I have completed the programming assignment independently.
   I have not copied the code from a student or any source.
   I have not given my code to any student.
   Print your Name here: _Mohammed Ali_
*/

package application;

public class HolidayBonus 
	{
		public HolidayBonus()
			{
				//nothing
			}
		
		public static double[] calculateHolidayBonus(double[][] dataPass, double highPass, double lowPass, double otherPass) 
			{
				int maxRowLength = 0;
				for (int row = 0; row < dataPass.length; row++) 
					{
						if (maxRowLength < dataPass[row].length) 
							{
								maxRowLength = dataPass[row].length;
							}
					}
			
			double[] holidayBonusArray;
			holidayBonusArray= new double[dataPass.length];

			int indexFor1;
			for (indexFor1 = 0; indexFor1 < dataPass.length; indexFor1++) 
				{
					holidayBonusArray[indexFor1] = 0;
				}
			
			int indexFor2;
			for (indexFor2 = 0; indexFor2 < maxRowLength; indexFor2++) 
				{
					int highestsStoreIndex;
					highestsStoreIndex = TwoDimRaggedArrayUtility.getHighestInColumnIndex(dataPass, indexFor2);
					int lowestsStoreIndex;
					lowestsStoreIndex = TwoDimRaggedArrayUtility.getLowestInColumnIndex(dataPass, indexFor2);
				
					if ((0 < dataPass[highestsStoreIndex][indexFor2]) && (lowestsStoreIndex == highestsStoreIndex)) 
						{
							holidayBonusArray[highestsStoreIndex] = holidayBonusArray[highestsStoreIndex] + highPass;
						}
					else 
						{
							int indexForRow1;
							for (indexForRow1 = 0; indexForRow1 < dataPass.length; indexForRow1++) 
								{
									if ((indexFor2 < dataPass[indexForRow1].length) && (0 < dataPass[indexForRow1][indexFor2])) 
										{
											if (dataPass[highestsStoreIndex][indexFor2] == dataPass[indexForRow1][indexFor2]) 
												{
													holidayBonusArray[indexForRow1] = holidayBonusArray[indexForRow1] + highPass;
												}
											else if (dataPass[lowestsStoreIndex][indexFor2] == dataPass[indexForRow1][indexFor2]) 
												{
													holidayBonusArray[indexForRow1] = holidayBonusArray[indexForRow1] + lowPass;
												}
											else 
												{
													holidayBonusArray[indexForRow1] = holidayBonusArray[indexForRow1] + otherPass;
												}
										}
								}
						}
				}
					return holidayBonusArray;
			}
	
		public static double calculateTotalHolidayBonus(double[][] dataPass, double highPass, double lowPass, double otherPass) 
			{
				double[] results;
				results = HolidayBonus.calculateHolidayBonus(dataPass, highPass, lowPass, otherPass);
				double tHB;
				tHB = 0;
				int indexFor5;
				
				for (indexFor5 = 0; indexFor5 < results.length; indexFor5++) 
					{
						tHB = tHB + results[indexFor5];
					}
			
				return tHB;
			}
	}