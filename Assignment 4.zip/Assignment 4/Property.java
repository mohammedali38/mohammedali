/*
 * Class: CMSC203 
 * Instructor: Professor Grigoriy Grinberg 
 * Description: Make a program that lets the users create a management company that manages individual properties that they build to rent and charges them 
 * a management fee as the percentages of the monthly rental amount.
 * Due: 07/17/2022
 * Platform/compiler: Eclipse
 * I pledge that I have completed the programming assignment independently.
   I have not copied the code from a student or any source.
   I have not given my code to any student.
   Print your Name here: _Mohammed Ali_
*/

package application;

public class Property 
	{
//fields
		private String city;
		private String owner;
		private String propertyName;
		private double rentAmount;
		private Plot plot;

//constructors	
/**
* No-arg Constructor
*/
		public Property () 
			{
				//empty strings
				city = "";
				owner = "";
				propertyName = "";
				//0 for rent amount (0.0 because its double)
				rentAmount = 0.0;
				//default plot
				plot = new Plot();
			}
		
/**
* constructor
* @param p
*/
		public Property(Property p)
			{	//copying from p. to this.
				this.city = p.city;
				this.owner = p.owner;
				this.rentAmount = p.rentAmount;
				this.propertyName = p.propertyName;
				this.plot = new Plot(p.plot);
			}
		
/**
* constructor
* @param propertyNamePass
* @param cityPass
* @param rentAmountPass
* @param ownerPass
*/
		public Property(String propertyNamePass, String cityPass, double rentAmountPass, String ownerPass)
			{
			//assigning
				propertyName = propertyNamePass;
				city = cityPass;
				rentAmount = rentAmountPass;
				owner = ownerPass;
				plot = new Plot();
			}
		
/**
* Parameterized constructor
* @param propertyNamePass
* @param cityPass
* @param rentAmountPass
* @param ownerPass
* @param xValuePass
* @param yValuePass
* @param widthPass
* @param depthPass
*/
		
		public Property(String propertyNamePass, String cityPass, double rentAmountPass, String ownerPass, int xValuePass, int yValuePass, int widthPass, int depthPass)
			{
			//assigning
				propertyName = propertyNamePass;
				city = cityPass;
				rentAmount = rentAmountPass;
				owner = ownerPass;
				plot = new Plot(xValuePass, yValuePass, widthPass, depthPass);
			}
		
		
//setters
		public Plot setPlot(int xValuePass, int yValuePass, int widthPass, int depthPass)
			{
				return new Plot(xValuePass, yValuePass, widthPass, depthPass);
			}
		public void setCity(String cityPass)
			{
				this.city = cityPass;
			}
		public void setOwner(String ownerPass)
			{
				this.owner = ownerPass;
			}
		public void setPropertyName(String propertyNamePass)
			{
				this.propertyName = propertyNamePass;
			}
		public void setRentAmount(double rentAmountPass)
			{
				this.rentAmount = rentAmountPass;
			}
		
		
//getters
		public String getCity()
			{
				return city;
			}
		public String getOwner()
			{
				return owner;
			}
		public String getPropertyName()
			{
				return propertyName;
			}
		public double getRentAmount()
			{
				return rentAmount;
			}
		public Plot getPlot()
			{
				return plot;
			}
		
//toString Method
		
/**
* Prints the name, city, owner and rent amount for a property
* toString method
*/
		public String toString()
			{
				String toStrProp;
				toStrProp = "Property Name: " + propertyName + "\n" + "Location: " 
										+ city + "\n" + "Belonging to: " + owner +
											"\n" + "Rent Amount: " + rentAmount;
				return toStrProp;
			}
}