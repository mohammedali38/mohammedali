/*
 * Class: CMSC203 
 * Instructor: Professor Grigoriy Grinberg 
 * Description: Make a program that lets the users create a management company that manages individual properties that they build to rent and charges them 
 * a management fee as the percentages of the monthly rental amount.
 * Due: 07/17/2022
 * Platform/compiler: Eclipse
 * I pledge that I have completed the programming assignment independently.
   I have not copied the code from a student or any source.
   I have not given my code to any student.
   Print your Name here: _Mohammed Ali_
*/

package application;

public class Plot 
	{
//fields
		private int x;
		private int y;
		private int width;
		private int depth;
		
//constructors
		
/**
* No-arg constructor
*/
		public Plot()
			{
				x = 0;
				y = 0;
				width = 1;
				depth = 1;
			}

/**
* Copy Constructor
* @param x
* @param y
* @param width
* @param depth
*/
		public Plot(Plot p) 
			{
				this.x = p.getX();
				this.y = p.getY();
				this.width = p.getWidth();
				this.depth = p.getDepth();
			}
		
/**
* parameterized constructor
* @param xValuePass
* @param yValuePass
* @param widthPass
* @param depthPass
*/
		public Plot(int xValuePass, int yValuePass, int widthPass, int depthPass) 
			{
				x = xValuePass;
				y = yValuePass;
				width = widthPass;
				depth = depthPass;
			}
		
		
		/**
		* Determines if this plot overlaps the parameter
		* @param p
		* @return true if plot overlaps the parameter, false if it doesn't
		*/
		public boolean overlaps(Plot p)
			{
				boolean firstOverlapXAndYOne;
				boolean firstOverlapXAndYTwo;
				boolean secondOverlapXAndYOne;
				boolean secondOverlapXAndYTwo;
				boolean thirdOverlapXAndYOne;
				boolean thirdOverlapXAndYTwo;
				boolean fourthOverlapXAndYOne;
				boolean fourthOverlapXAndYTwo;

				firstOverlapXAndYOne = ((((x + width) > p.x) && (x <= p.x))		&&		(((y + depth) > p.y) && (y <= p.y)));
				firstOverlapXAndYTwo =  ((((p.x + width) > x) && (x >= p.x))		&&		(((p.depth + p.y) > y) && (y >= p.y)));
				secondOverlapXAndYOne = ((((x + width) > (p.x + p.width)) && (x < (p.x + p.width)))		&&		(((y + depth) >= p.y) &&	(y <= p.y)));
				secondOverlapXAndYTwo = (((x + width) < (p.x + p.width)) && ((x + width) > p.x))		&&		(((p.y + p.depth) >= y) && (y >= p.y));
				thirdOverlapXAndYOne = ((((x + width) > p.x) && (x <= p.x))		&&		(((p.y + p.depth) > y) && ((p.y + p.depth) <= (y + depth))));
				thirdOverlapXAndYTwo = ((((p.x + p.width) > x) && (x >= p.x))		&&		(((y + depth) > p.y) && ((y + depth) <= (p.y + p.depth))));
				fourthOverlapXAndYOne = ((((x + width) >= (p.x + p.width)) && ((p.x + p.width) > x))		&&		(((p.y + p.depth) > y) && ((p.y + p.depth) <= (y + depth))));
				fourthOverlapXAndYTwo = ((((x + width) > p.x) && ((x + width) <= (p.x + p.width)))		&&		(((y + depth) > p.y) && ((y + depth) <= (p.y + p.depth))));

				return (firstOverlapXAndYOne || firstOverlapXAndYTwo || secondOverlapXAndYOne || secondOverlapXAndYTwo || thirdOverlapXAndYOne|| thirdOverlapXAndYTwo || fourthOverlapXAndYOne || fourthOverlapXAndYTwo);
			}

/**
* decide if this plot encompasses the parameter
* @param p
* @return Returns true if this plot encompasses the parameter, false if it doesn't
*/
		public boolean encompasses(Plot p)
			{
				boolean inValueX;
				boolean inValueY;
				boolean inValueWidth;
				boolean inValueDepth;
			
				inValueX = (x <= p.x);
				inValueY = (y <= p.y);
				inValueWidth = ((p.width + p.x) <= (x + width));
				inValueDepth = ((p.depth + p.y) <= (y + depth));
			
				return (inValueX && inValueY && inValueWidth && inValueDepth);
			}
		
//setters
		public void setX(int xValuePass)
			{
				x = xValuePass;
			}
		public void setY(int yValuePass)
			{
				y = yValuePass;
			}
		public void setWidth(int widthPass)
			{
				width = widthPass;
			}
		public void setDepth(int depthPass)
			{
				depth = depthPass;
			}
//getters
		public int getX()
			{
				return x;
			}
		public int getY()
			{
				return y;
			}
		public int getWidth()
			{
				return width;
			}
		public int getDepth()
			{
				return depth;
			}
		


//toString method


		public String toString()
			{
				String toStrPlot;
				toStrPlot = "Upper left: (" + x + "," + y + "); Width: " + width + " Depth: " + depth;
				
				return toStrPlot;
			}
}