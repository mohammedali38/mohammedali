/*
 * Class: CMSC203 
 * Instructor: Professor Grigoriy Grinberg 
 * Description: Make a program that lets the users create a management company that manages individual properties that they build to rent and charges them 
 * a management fee as the percentages of the monthly rental amount.
 * Due: 07/17/2022
 * Platform/compiler: Eclipse
 * I pledge that I have completed the programming assignment independently.
   I have not copied the code from a student or any source.
   I have not given my code to any student.
   Print your Name here: _Mohammed Ali_
*/

package application;

public class ManagementCompany 
	{
//fields
		private final int MAX_PROPERTY = 5;
		private final int MGMT_WIDTH = 10;
		private final int MGMT_DEPTH = 10;
		private double mgmFeePer;
		private String name;
		private String taxID;
		private Plot plot;
		private Property properties[];
	
/**
* No-arg constructor
*/
		public ManagementCompany() 
			{
				name = "";
				taxID = "";
				mgmFeePer = 0.0;
				plot = new Plot(0, 0, 10, 10);
				properties = new Property[MAX_PROPERTY];
				int indexMG1;
				for (indexMG1 = 0; indexMG1 < MAX_PROPERTY; indexMG1++) 
					{
						properties[indexMG1] = new Property();
					}
			}

/**
* constructor2
*/
		public ManagementCompany(String namePass, String taxIDPass, double mgmFeePerPass) 
			{
				name = namePass;
				taxID = taxIDPass;
				mgmFeePer = mgmFeePerPass;
				plot = new Plot(0, 0, 10, 10);
				properties = new Property[MAX_PROPERTY];
				int indexMG2;
				for (indexMG2 = 0; indexMG2 < MAX_PROPERTY; indexMG2++) 
					{
						properties[indexMG2] = new Property();
					}
			}
/**
* constructor3
*/
		public ManagementCompany(String namePass, String taxIDPass, double mgmFeePerPass, int xValuePass, int yValuePass, int widthPass, int depthPass) 
			{
				name = namePass;
				taxID = taxIDPass;
				mgmFeePer = mgmFeePerPass;
				plot = new Plot(xValuePass, yValuePass, widthPass, depthPass);
				properties = new Property[MAX_PROPERTY];
				int indexMG3;
				for (indexMG3 = 0; indexMG3 < MAX_PROPERTY; indexMG3++) 
					{
						properties[indexMG3] = new Property();
					}
			}
/**
*Copy constructor
*/
		public ManagementCompany(ManagementCompany newCompany) 
			{
				this.name = newCompany.name;
				this.taxID = newCompany.taxID;
				this.mgmFeePer = newCompany.mgmFeePer;
				this.plot = new Plot(newCompany.getPlot().getX(), newCompany.getPlot().getY(), newCompany.getPlot().getWidth(), newCompany.getPlot().getDepth());
				this.properties = new Property[MAX_PROPERTY];
				int indexMG4;
				for (indexMG4 = 0; indexMG4 < MAX_PROPERTY; indexMG4++) 
					{
						this.properties[indexMG4] = new Property(newCompany.properties[indexMG4]);
					}
			}
		
/**
* addProperty1
* @param propertyPass
* @return Returns -1 if the array is full, -2 if property is null, -3 if the plot is not contained by plot, -4 of the plot overlaps other property, or index in array where the property was added properly
*/
		public int addProperty(Property propertyPass) 
			{
				Property propAdd1;
				propAdd1 = new Property(propertyPass);
				int indexAP1;
				indexAP1 = 0;
				int elementAP1;
				elementAP1 = -1;
				boolean finder;
				finder = false;
				int addPropReturner;
				int indexForAP1;
				
				while((MAX_PROPERTY > indexAP1) && (finder == false)) 
					{
						if((this.properties[indexAP1] == null) || ((this.properties[indexAP1].getRentAmount() == 0.0) && (this.properties[indexAP1].getPropertyName().equals("")) && (this.properties[indexAP1].getCity().equals("")) && (this.properties[indexAP1].getOwner().equals("")))) 
							{
								finder = true;
								elementAP1 = indexAP1;
							}
						indexAP1++;
					}
				
				if(finder = false)
					{
						addPropReturner = -1;
						return addPropReturner;
					}
				else if(propAdd1.equals(null) == true) 
					{
						addPropReturner = -2;
						return addPropReturner;
					}
				else if((this.plot.encompasses(propAdd1.getPlot())) == false) 
					{
						addPropReturner = -3;
						return addPropReturner;
					}
				else 
					{
						for(indexForAP1 = 0; indexForAP1 < MAX_PROPERTY; indexForAP1++) 
							{
								if((this.properties[indexForAP1].getPropertyName().equals("")) == false) 
									{
										if((this.properties[indexForAP1].getPlot().overlaps(propAdd1.getPlot())) == true) 
											{
												addPropReturner = -4;
												return addPropReturner;
											}
									}
							}
						
						this.properties[elementAP1] = new Property(propAdd1);
						
						return elementAP1;
					}
			}
/**
* addProperty2
* @param namePass
* @param cityPass
* @param rentPass
* @param ownerPass
* @return returns -1 if array is full, -2 if property is null, -3 if plot is not contained by the MgmtCo plot, -4 if plot overlaps any other property, or the index in the array where the property was added properly
*/
		public int addProperty(String namePass, String cityPass, double rentPass, String ownerPass) 
			{
				Property propAdd2;
				propAdd2 = new Property(namePass, cityPass, rentPass, ownerPass);
				int indexAP2;
				indexAP2 = 0;
				int elementAP2;
				elementAP2= -1;
				boolean finder;
				finder = false;
				int addPropReturner;
				int indexForAP2;
				
				while((MAX_PROPERTY > indexAP2) && (finder == false)) 
					{
						if((this.properties[indexAP2] == null) || ((this.properties[indexAP2].getRentAmount() == 0.0) && (this.properties[indexAP2].getPropertyName().equals("")) && (this.properties[indexAP2].getCity().equals("")) && (this.properties[indexAP2].getOwner().equals(""))))
							{
								finder = true;
								elementAP2 = indexAP2;
							}
						indexAP2++;
					}
				
				if(finder == false) 
					{
						addPropReturner = -1;
						return addPropReturner;
					}
				else if(propAdd2.equals(null)) 
					{
						addPropReturner = -2;
						return addPropReturner;
					}
				else if((this.plot.encompasses(propAdd2.getPlot())) == false) 
					{
						addPropReturner = -3;
						return addPropReturner;
					}
				else 
					{
						for(indexForAP2 = 0; indexForAP2 < MAX_PROPERTY; indexForAP2++) 
							{
								if((this.properties[indexForAP2].getPropertyName().equals("")) == false) 
									{
										if((this.properties[indexForAP2].getPlot().overlaps(propAdd2.getPlot())) == true) 
											{
												addPropReturner = -4;
												return addPropReturner;
											}
									}
							}
						
						this.properties[elementAP2] = new Property(propAdd2);
						
						return elementAP2;
					}
			}	
			
/**
* addProperty3
* @param namePass
* @param cityPass
* @param rentPass
* @param ownerPass
* @param xValuePass
* @param yValuePass
* @param widthPass
* @param depthPass
* @return Returns -1 if array is full, -2 if property is null, -3 if the plot is not contained by the MgmtCo plot, -4 of the plot overlaps any other property, or index in the array where the property was added properly
*/
		public int addProperty(String namePass, String cityPass, double rentPass, String ownerPass, int xValuePass, int yValuePass, int widthPass, int depthPass) 
			{
				Property addProp3;
				addProp3= new Property(namePass, cityPass, rentPass, ownerPass, xValuePass, yValuePass, widthPass, depthPass);
				int indexAP3;
				indexAP3 = 0;
				int elementAP3;
				elementAP3= -1;
				boolean finder;
				finder = false;
				int addPropReturner;
				int indexForAP3;
				
				while((MAX_PROPERTY > indexAP3) && (finder == false)) 
					{
						if((this.properties[indexAP3] == null) || ((this.properties[indexAP3].getRentAmount() == 0.0) && (this.properties[indexAP3].getPropertyName().equals("")) && (this.properties[indexAP3].getCity().equals("")) && (this.properties[indexAP3].getOwner().equals(""))))
							{
								finder = true;
								elementAP3 = indexAP3;
							}
						indexAP3++;
					}
				
				if(finder == false) 
					{
						addPropReturner = -1;
						return addPropReturner;
					}
				else if(addProp3.equals(null)) 
					{
						addPropReturner = -2;
						return addPropReturner;
					}
				else if((this.plot.encompasses(addProp3.getPlot())) == false) 
					{
						addPropReturner = -3;
						return addPropReturner;
					}
				else 
					{
						for(indexForAP3 = 0; indexForAP3 < MAX_PROPERTY; indexForAP3++) 
							{
								if((this.properties[indexForAP3].getPropertyName().equals("")) == false) 
									{
										if((this.properties[indexForAP3].getPlot().overlaps(addProp3.getPlot())) == true) 
											{
												addPropReturner = -4;
												return addPropReturner;
											}
									}
							}
						
				this.properties[elementAP3] = new Property(addProp3);
				
				return elementAP3;
			}
		}
		
//getters
/**
* Return name of management company
* @return name of management company
*/
		public String getName() 
			{
				return name;
			}
	
/**
* Return the management company Plot
* @return Plot for the management company
*/
		public Plot getPlot() 
			{
				return new Plot(plot.getX(), plot.getY(), plot.getWidth(), plot.getDepth());
			}
		
/**
* Return MAX_PROPERTY constant that represents size of the array
* @return MAX_PROPERTY (5)
*/
		public int getMAX_PROPERTY() 
			{
				return MAX_PROPERTY;
			}
	
//other methods
/**
*method accesses each Property object within the array called properties and adds up the property rent. Then it returns the total
* @return total rent
 */
		public double totalRent() 
			{
				double totalR;
				totalR = 0;
				int indexTR;
				
				for (indexTR = 0; indexTR < MAX_PROPERTY; indexTR++) 
					{
						totalR = (totalR + (this.properties[indexTR].getRentAmount()));
					}
				
				return totalR;
			}
		
/**
*method finds the property with the max rent amount and returns rent amount
*@return the maximum rent amount, a double
*/
		public double maxRentProp() 
			{
				double mRP;
				mRP = (this.properties[maxRentPropertyIndex()].getRentAmount());
				return mRP;
			}
/**
*method finds index of property with the max rent amount
*@return index of the property with the max rent amount
*/
		private int maxRentPropertyIndex() 
			{
				int maxRenPropIndex;
				maxRenPropIndex = 0;
				int indexForMRPI;
				
				for (indexForMRPI = 1; indexForMRPI < MAX_PROPERTY; indexForMRPI++) 
					{
						if ((this.properties[maxRenPropIndex].getRentAmount()) < (this.properties[indexForMRPI].getRentAmount())) 
							{
								maxRenPropIndex = indexForMRPI;
							}
					}
				
				return maxRenPropIndex;
			}

/**
*Displays info of property at index indexPass
*@param indexPass
*@return information of the property at index indexPass
*/
		private String displayPropertyAtIndex(int indexPass) 
			{
				String strDPAI;
				strDPAI = (this.properties[indexPass].toString());
				
				return strDPAI;
			}
/**
* Displays the information of all the properties in the "properties" array.
* @return The string representation of information of ALL the properties within this management company by accessing the "Properties" array.
*/

		public String toString() 
			{
				String toStrManComp;
				toStrManComp = "List of the properties for " + this.name + ", taxID: " + this.taxID + "\n" + "___________________________________________________";
				int indexToStr;
				
				
				for (indexToStr = 0; indexToStr < MAX_PROPERTY; indexToStr++) 
					{
						toStrManComp += ("\n" + displayPropertyAtIndex(indexToStr));
					}
				
				toStrManComp =  toStrManComp + ("\n" + "___________________________________________________\ntotal management Fee: " + ((this.mgmFeePer / 100) * totalRent()));
				
				return toStrManComp;
			}
		
	}